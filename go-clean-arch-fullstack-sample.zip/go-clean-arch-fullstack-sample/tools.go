//go:build tools
// +build tools

// Package tools pins build-time tool dependencies (Wire codegen, templ) so
// `go generate` resolves them from go.mod. Never compiled into the app.
package tools

import (
	_ "github.com/a-h/templ/cmd/templ"
	_ "github.com/google/wire/cmd/wire"
)
