package main

import (
	"go-clean-arch-fullstack-sample/internal/config"

	common "github.com/te0tl/go-clean-arch-base/mongo/pkg/repository/common"
)

// provideMongoClient is a Wire provider that opens the Mongo connection from
// config. It returns an error, which Wire threads up so InitializeApp returns
// (*App, error) and a bad connection fails startup.
func provideMongoClient(cfg *config.Config) (*common.MongoClient, error) {
	return common.NewMongoClient(cfg.MongoURI, "go-clean-arch-fullstack-sample-"+string(cfg.Env))
}
