//go:build wireinject
// +build wireinject

package main

import (
	"go-clean-arch-fullstack-sample/internal/config"
	note_controller "go-clean-arch-fullstack-sample/internal/controller/http/note"
	"go-clean-arch-fullstack-sample/internal/domain/note"
	note_repository "go-clean-arch-fullstack-sample/internal/repository/note"
	"go-clean-arch-fullstack-sample/internal/usecases/note/createNote"
	"go-clean-arch-fullstack-sample/internal/usecases/note/deleteNote"
	"go-clean-arch-fullstack-sample/internal/usecases/note/listNotes"

	"github.com/google/wire"
)

// InfraSet provides infrastructure singletons (the Mongo client).
var InfraSet = wire.NewSet(
	provideMongoClient,
)

// RepositorySet provides the repository adapters and binds them to their ports.
var RepositorySet = wire.NewSet(
	note_repository.NewNoteRepository,
	wire.Bind(new(note.Repository), new(*note_repository.NoteRepository)),
)

// UsecaseSet provides the application usecases.
var UsecaseSet = wire.NewSet(
	createNote.NewCreateNoteUsecase,
	listNotes.NewListNotesUsecase,
	deleteNote.NewDeleteNoteUsecase,
)

// ControllerSet provides the HTTP controllers.
var ControllerSet = wire.NewSet(
	note_controller.NewNoteController,
)

// InitializeApp is the Wire injector. provideMongoClient can fail, so the
// injector (and thus InitializeApp) returns an error.
func InitializeApp(cfg *config.Config) (*App, error) {
	wire.Build(
		InfraSet,
		RepositorySet,
		UsecaseSet,
		ControllerSet,
		newApp,
	)
	return nil, nil
}
