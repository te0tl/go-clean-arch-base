package main

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func RegisterRoutes(engine *gin.Engine, app *App) {
	engine.GET("/healthz", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok"})
	})

	engine.GET("/", app.NoteController.Index)
	engine.POST("/notes", app.NoteController.Create)
	engine.DELETE("/notes/:id", app.NoteController.Delete)
}
