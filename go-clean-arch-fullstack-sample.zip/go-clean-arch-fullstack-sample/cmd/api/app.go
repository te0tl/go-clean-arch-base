package main

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"

	"go-clean-arch-fullstack-sample/internal/config"
	note_controller "go-clean-arch-fullstack-sample/internal/controller/http/note"
	"go-clean-arch-fullstack-sample/internal/infrastructure/http/router"

	// httperrors wires htmx.Default in its init(); imported for the side effect.
	_ "go-clean-arch-fullstack-sample/internal/infrastructure/http/httperrors"

	common "github.com/te0tl/go-clean-arch-base/mongo/pkg/repository/common"

	"github.com/gin-gonic/gin"
)

// App holds the wired application. Wire assembles it via InitializeApp
// (wire.go / wire_gen.go) — no manual wireDependencies().
type App struct {
	Config         *config.Config
	MongoClient    *common.MongoClient
	Server         *http.Server
	NoteController *note_controller.NoteController
}

// newApp is the Wire provider that assembles the App and configures the HTTP
// server from the wired dependencies.
func newApp(
	cfg *config.Config,
	mongoClient *common.MongoClient,
	noteController *note_controller.NoteController,
) *App {
	app := &App{
		Config:         cfg,
		MongoClient:    mongoClient,
		NoteController: noteController,
	}

	r := router.SetupRouter(cfg, func(engine *gin.Engine) {
		RegisterRoutes(engine, app)
	})

	app.Server = &http.Server{
		Addr:    fmt.Sprintf(":%d", cfg.Port),
		Handler: r,
	}
	return app
}

func (app *App) StartServer() error {
	slog.Info("Starting HTTP server", "addr", app.Server.Addr)
	go func() {
		if err := app.Server.ListenAndServe(); err != http.ErrServerClosed {
			slog.Error("HTTP server error", "error", err)
		}
	}()
	return nil
}

func (app *App) CloseApp(ctx context.Context) error {
	slog.Info("Shutting down...")
	if err := app.Server.Shutdown(ctx); err != nil {
		return fmt.Errorf("error shutting down server: %w", err)
	}
	if err := app.MongoClient.Close(ctx); err != nil {
		return fmt.Errorf("error closing MongoDB: %w", err)
	}
	slog.Info("Shutdown complete")
	return nil
}
