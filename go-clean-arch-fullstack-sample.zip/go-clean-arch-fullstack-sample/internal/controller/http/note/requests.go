package note_controller

// createNoteRequest binds the note form. No `binding` tags: the usecase owns
// validation (returns note.ErrTitleRequired, which the htmx layer maps to a
// 422 validation fragment). Trimming happens in the controller.
type createNoteRequest struct {
	Title string `form:"title"`
	Body  string `form:"body"`
}
