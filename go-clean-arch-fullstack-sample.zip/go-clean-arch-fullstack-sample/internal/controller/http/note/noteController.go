package note_controller

import (
	"strings"

	"go-clean-arch-fullstack-sample/internal/usecases/note/createNote"
	"go-clean-arch-fullstack-sample/internal/usecases/note/deleteNote"
	"go-clean-arch-fullstack-sample/internal/usecases/note/listNotes"
	"go-clean-arch-fullstack-sample/internal/view"
	note_view "go-clean-arch-fullstack-sample/internal/view/note"

	"github.com/te0tl/go-clean-arch-base/web/pkg/infrastructure/http/htmx"

	"github.com/gin-gonic/gin"
)

type NoteController struct {
	createNoteUC *createNote.Usecase
	listNotesUC  *listNotes.Usecase
	deleteNoteUC *deleteNote.Usecase
}

func NewNoteController(
	createNoteUC *createNote.Usecase,
	listNotesUC *listNotes.Usecase,
	deleteNoteUC *deleteNote.Usecase,
) *NoteController {
	return &NoteController{
		createNoteUC: createNoteUC,
		listNotesUC:  listNotesUC,
		deleteNoteUC: deleteNoteUC,
	}
}

// Index renders the full page (GET /).
func (ctrl *NoteController) Index(c *gin.Context) {
	notes, err := ctrl.listNotesUC.Execute(c.Request.Context())
	if err != nil {
		htmx.RespondHTMX(c, err)
		return
	}
	view.OK(c, note_view.IndexPage(notes))
}

// Create handles POST /notes and swaps the refreshed list on success.
func (ctrl *NoteController) Create(c *gin.Context) {
	var req createNoteRequest
	_ = c.ShouldBind(&req)

	_, err := ctrl.createNoteUC.Execute(c.Request.Context(), createNote.Input{
		Title: strings.TrimSpace(req.Title),
		Body:  strings.TrimSpace(req.Body),
	})
	if err != nil {
		htmx.RespondHTMX(c, err)
		return
	}

	ctrl.renderList(c)
}

// Delete handles DELETE /notes/:id and swaps the refreshed list on success.
func (ctrl *NoteController) Delete(c *gin.Context) {
	if err := ctrl.deleteNoteUC.Execute(c.Request.Context(), c.Param("id")); err != nil {
		htmx.RespondHTMX(c, err)
		return
	}
	ctrl.renderList(c)
}

func (ctrl *NoteController) renderList(c *gin.Context) {
	notes, err := ctrl.listNotesUC.Execute(c.Request.Context())
	if err != nil {
		htmx.RespondHTMX(c, err)
		return
	}
	view.OK(c, note_view.List(notes))
}
