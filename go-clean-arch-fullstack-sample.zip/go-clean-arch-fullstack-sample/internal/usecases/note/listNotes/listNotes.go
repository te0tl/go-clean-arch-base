package listNotes

import (
	"context"
	"fmt"

	"go-clean-arch-fullstack-sample/internal/domain/note"
)

type Usecase struct {
	repo note.Repository
}

func NewListNotesUsecase(repo note.Repository) *Usecase {
	return &Usecase{repo: repo}
}

func (u *Usecase) Execute(ctx context.Context) ([]*note.Note, error) {
	notes, err := u.repo.List(ctx)
	if err != nil {
		return nil, fmt.Errorf("listing notes: %w", err)
	}
	return notes, nil
}
