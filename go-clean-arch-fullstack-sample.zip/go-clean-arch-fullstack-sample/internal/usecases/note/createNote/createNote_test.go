package createNote

import (
	"context"
	"errors"
	"testing"

	"go-clean-arch-fullstack-sample/internal/domain/note"

	errorsWrapper "github.com/pkg/errors"
	errors_domain "github.com/te0tl/go-clean-arch-base/core/pkg/domain/errors"
	"github.com/te0tl/go-clean-arch-base/core/pkg/testutils"

	"github.com/stretchr/testify/assert"
)

type mockRepo struct {
	insertErr    error
	insertCalled bool
	inserted     *note.Note
}

func (m *mockRepo) Insert(_ context.Context, n *note.Note) error {
	m.insertCalled = true
	m.inserted = n
	return m.insertErr
}
func (m *mockRepo) List(_ context.Context) ([]*note.Note, error)      { return nil, nil }
func (m *mockRepo) Delete(_ context.Context, _ string) (bool, error) { return false, nil }

func TestCreateNoteUsecase_Execute(t *testing.T) {
	t.Run("returns ErrTitleRequired when title is empty", func(t *testing.T) {
		m := &mockRepo{}
		uc := NewCreateNoteUsecase(m)

		_, err := uc.Execute(context.Background(), Input{Title: "", Body: "x"})

		testutils.ErrorAssertions(t, err, note.ErrTitleRequired, true)
		assert.True(t, errors.Is(err, errors_domain.ErrInvalidInput))
		assert.False(t, m.insertCalled)
	})

	t.Run("propagates repository insert error", func(t *testing.T) {
		m := &mockRepo{insertErr: errorsWrapper.New("mongo down")}
		uc := NewCreateNoteUsecase(m)

		_, err := uc.Execute(context.Background(), Input{Title: "Hola", Body: "x"})

		testutils.ErrorMessageAssertions(t, err, "mongo down", true)
		assert.True(t, m.insertCalled)
	})

	t.Run("happy path assigns id/timestamps and inserts", func(t *testing.T) {
		m := &mockRepo{}
		uc := NewCreateNoteUsecase(m)

		out, err := uc.Execute(context.Background(), Input{Title: "Hola", Body: "mundo"})

		assert.NoError(t, err)
		assert.NotEmpty(t, out.ID)
		assert.Equal(t, "Hola", out.Title)
		assert.False(t, out.CreatedAt.IsZero())
		assert.True(t, m.insertCalled)
		assert.Equal(t, out, m.inserted)
	})
}
