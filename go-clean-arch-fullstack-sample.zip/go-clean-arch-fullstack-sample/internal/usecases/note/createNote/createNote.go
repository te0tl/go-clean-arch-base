package createNote

import (
	"context"
	"fmt"
	"time"

	"go-clean-arch-fullstack-sample/internal/domain/note"

	"github.com/google/uuid"
	errorsWrapper "github.com/pkg/errors"
)

type Usecase struct {
	repo note.Repository
}

func NewCreateNoteUsecase(repo note.Repository) *Usecase {
	return &Usecase{repo: repo}
}

type Input struct {
	Title string
	Body  string
}

func (u *Usecase) Execute(ctx context.Context, in Input) (*note.Note, error) {
	if in.Title == "" {
		return nil, errorsWrapper.Wrap(note.ErrTitleRequired, "validating input")
	}

	now := time.Now().UTC()
	n := &note.Note{
		ID:        uuid.NewString(),
		Title:     in.Title,
		Body:      in.Body,
		CreatedAt: now,
		UpdatedAt: now,
	}

	if err := u.repo.Insert(ctx, n); err != nil {
		return nil, fmt.Errorf("inserting note: %w", err)
	}

	return n, nil
}
