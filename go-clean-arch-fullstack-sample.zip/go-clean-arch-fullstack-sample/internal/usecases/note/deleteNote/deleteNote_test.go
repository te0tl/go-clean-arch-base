package deleteNote

import (
	"context"
	"testing"

	"go-clean-arch-fullstack-sample/internal/domain/note"

	errorsWrapper "github.com/pkg/errors"
	"github.com/te0tl/go-clean-arch-base/core/pkg/testutils"

	"github.com/stretchr/testify/assert"
)

type mockRepo struct {
	deleted      bool
	deleteErr    error
	deleteCalled bool
}

func (m *mockRepo) Insert(_ context.Context, _ *note.Note) error { return nil }
func (m *mockRepo) List(_ context.Context) ([]*note.Note, error) { return nil, nil }
func (m *mockRepo) Delete(_ context.Context, _ string) (bool, error) {
	m.deleteCalled = true
	return m.deleted, m.deleteErr
}

func TestDeleteNoteUsecase_Execute(t *testing.T) {
	t.Run("returns ErrNoteNotFound when id is empty", func(t *testing.T) {
		m := &mockRepo{}
		uc := NewDeleteNoteUsecase(m)

		err := uc.Execute(context.Background(), "")

		testutils.ErrorAssertions(t, err, note.ErrNoteNotFound, true)
		assert.False(t, m.deleteCalled)
	})

	t.Run("propagates repository delete error", func(t *testing.T) {
		m := &mockRepo{deleteErr: errorsWrapper.New("mongo down")}
		uc := NewDeleteNoteUsecase(m)

		err := uc.Execute(context.Background(), "abc")

		testutils.ErrorMessageAssertions(t, err, "mongo down", true)
		assert.True(t, m.deleteCalled)
	})

	t.Run("returns ErrNoteNotFound when nothing was deleted", func(t *testing.T) {
		m := &mockRepo{deleted: false}
		uc := NewDeleteNoteUsecase(m)

		err := uc.Execute(context.Background(), "missing")

		testutils.ErrorAssertions(t, err, note.ErrNoteNotFound, true)
		assert.True(t, m.deleteCalled)
	})

	t.Run("happy path deletes", func(t *testing.T) {
		m := &mockRepo{deleted: true}
		uc := NewDeleteNoteUsecase(m)

		err := uc.Execute(context.Background(), "abc")

		assert.NoError(t, err)
		assert.True(t, m.deleteCalled)
	})
}
