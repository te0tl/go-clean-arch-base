package deleteNote

import (
	"context"
	"fmt"

	"go-clean-arch-fullstack-sample/internal/domain/note"

	errorsWrapper "github.com/pkg/errors"
)

type Usecase struct {
	repo note.Repository
}

func NewDeleteNoteUsecase(repo note.Repository) *Usecase {
	return &Usecase{repo: repo}
}

func (u *Usecase) Execute(ctx context.Context, id string) error {
	if id == "" {
		return errorsWrapper.Wrap(note.ErrNoteNotFound, "empty id")
	}

	deleted, err := u.repo.Delete(ctx, id)
	if err != nil {
		return fmt.Errorf("deleting note: %w", err)
	}
	if !deleted {
		return errorsWrapper.Wrap(note.ErrNoteNotFound, id)
	}

	return nil
}
