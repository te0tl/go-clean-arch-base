package note

import (
	"fmt"

	errors_domain "github.com/te0tl/go-clean-arch-base/core/pkg/domain/errors"
)

// Domain sentinels wrap a canonical category so the htmx layer maps them to the
// right HTTP status + fragment, while callers can still match the specific
// sentinel via errors.Is.
var (
	ErrTitleRequired = fmt.Errorf("%w: el título es obligatorio", errors_domain.ErrInvalidInput)
	ErrNoteNotFound  = fmt.Errorf("%w: nota no encontrada", errors_domain.ErrNotFound)
)
