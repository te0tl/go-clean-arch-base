package note

import (
	"context"
	"time"
)

// Note is the domain entity. Plain Go — no BSON tags, no framework types. The
// repository adapter maps this to/from its storage representation.
type Note struct {
	ID        string
	Title     string
	Body      string
	CreatedAt time.Time
	UpdatedAt time.Time
}

// Repository is the persistence port. The mongo adapter in
// internal/repository/note implements it; usecases depend on this interface.
type Repository interface {
	Insert(ctx context.Context, n *Note) error
	List(ctx context.Context) ([]*Note, error)
	Delete(ctx context.Context, id string) (deleted bool, err error)
}
