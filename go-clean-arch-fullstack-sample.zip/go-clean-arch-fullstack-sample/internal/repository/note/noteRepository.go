package note

import (
	"context"
	"time"

	domain_note "go-clean-arch-fullstack-sample/internal/domain/note"

	common "github.com/te0tl/go-clean-arch-base/mongo/pkg/repository/common"

	errorsWrapper "github.com/pkg/errors"
	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

const NOTE_COLLECTION = "notes"

// noteDoc is the BSON representation. Keeping it separate from the domain
// entity means the domain never carries storage tags (BSON ↔ entidad).
type noteDoc struct {
	ID        string    `bson:"_id"`
	Title     string    `bson:"title"`
	Body      string    `bson:"body"`
	CreatedAt time.Time `bson:"createdAt"`
	UpdatedAt time.Time `bson:"updatedAt"`
}

func toDoc(n *domain_note.Note) noteDoc {
	return noteDoc{
		ID:        n.ID,
		Title:     n.Title,
		Body:      n.Body,
		CreatedAt: n.CreatedAt,
		UpdatedAt: n.UpdatedAt,
	}
}

func (d noteDoc) toDomain() *domain_note.Note {
	return &domain_note.Note{
		ID:        d.ID,
		Title:     d.Title,
		Body:      d.Body,
		CreatedAt: d.CreatedAt,
		UpdatedAt: d.UpdatedAt,
	}
}

type NoteRepository struct {
	collection *mongo.Collection
}

func NewNoteRepository(mongoClient *common.MongoClient) *NoteRepository {
	return &NoteRepository{
		collection: mongoClient.DatabaseCommons.Collection(NOTE_COLLECTION),
	}
}

func (r *NoteRepository) Insert(ctx context.Context, n *domain_note.Note) error {
	if _, err := r.collection.InsertOne(ctx, toDoc(n)); err != nil {
		return errorsWrapper.Wrap(err, "inserting note")
	}
	return nil
}

func (r *NoteRepository) List(ctx context.Context) ([]*domain_note.Note, error) {
	cursor, err := r.collection.Find(ctx, bson.M{}, options.Find().SetSort(bson.D{{Key: "createdAt", Value: -1}}))
	if err != nil {
		return nil, errorsWrapper.Wrap(err, "finding notes")
	}

	var docs []noteDoc
	if err := cursor.All(ctx, &docs); err != nil {
		return nil, errorsWrapper.Wrap(err, "decoding notes")
	}

	notes := make([]*domain_note.Note, 0, len(docs))
	for _, d := range docs {
		notes = append(notes, d.toDomain())
	}
	return notes, nil
}

func (r *NoteRepository) Delete(ctx context.Context, id string) (bool, error) {
	res, err := r.collection.DeleteOne(ctx, bson.M{"_id": id})
	if err != nil {
		return false, errorsWrapper.Wrap(err, "deleting note")
	}
	return res.DeletedCount > 0, nil
}
