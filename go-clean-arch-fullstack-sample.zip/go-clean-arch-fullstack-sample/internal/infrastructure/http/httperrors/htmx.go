// Package httperrors wires the shared htmx error handler with this project's
// fragments. Imported for its side effect (init) from cmd/api — do not delete.
//
// The base web module owns the error→status mapping; the project only supplies
// the fragment factories (its own design system) and, optionally, a
// ProjectMapper for project-specific sentinels. See base HTMX_ERROR_HANDLING.md.
package httperrors

import (
	common_view "go-clean-arch-fullstack-sample/internal/view/common"

	"github.com/te0tl/go-clean-arch-base/web/pkg/infrastructure/http/htmx"
)

func init() {
	htmx.Default = htmx.Config{
		Fragments: htmx.CanonicalFragments{
			Validation:   func(m string) htmx.Renderable { return common_view.ValidationAlert(m) },
			NotFound:     func(m string) htmx.Renderable { return common_view.InfoAlert(m) },
			Unauthorized: func() htmx.Renderable { return common_view.Banner("No autorizado.") },
			Forbidden:    func() htmx.Renderable { return common_view.Banner("Prohibido.") },
			Banner:       func(m string) htmx.Renderable { return common_view.Banner(m) },
		},
		Render: htmx.DefaultRender,
	}
}
