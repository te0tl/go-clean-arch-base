package config

import (
	base_config "github.com/te0tl/go-clean-arch-base/core/pkg/config"
)

// Config is the application configuration. This fullstack sample persists to
// MongoDB, so it embeds config.Base plus the optional config.Mongo fragment.
// It does not embed JWT/Email/Frontend because this sample doesn't use them —
// add those fragments when a feature needs them.
type Config struct {
	base_config.Base
	base_config.Mongo
}

func Load() *Config {
	cfg := &Config{}
	base_config.LoadEnv(cfg)
	cfg.Validate()
	return cfg
}
