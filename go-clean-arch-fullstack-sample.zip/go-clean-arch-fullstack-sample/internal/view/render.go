package view

import (
	"net/http"

	"github.com/a-h/templ"
	"github.com/gin-gonic/gin"
)

// Render writes a templ component as an HTML response with the given status.
// Server-side rendering entry point used by controllers.
func Render(c *gin.Context, status int, comp templ.Component) {
	c.Status(status)
	c.Header("Content-Type", "text/html; charset=utf-8")
	_ = comp.Render(c.Request.Context(), c.Writer)
}

// OK is Render with http.StatusOK.
func OK(c *gin.Context, comp templ.Component) {
	Render(c, http.StatusOK, comp)
}
