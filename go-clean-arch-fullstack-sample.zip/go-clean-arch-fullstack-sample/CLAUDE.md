# CLAUDE.md — go-clean-arch-fullstack-sample

@../go-clean-arch-base/CLAUDE.md

Sample **fullstack** (Gin + templ + HTMX + MongoDB). Molde para migrar checatufon:
tomará el subconjunto `core` + `web` (htmx) y, si no persiste, dejará fuera `mongo`.

## Qué demuestra

- Consume **`core` + `mongo` + `web`** (+ `logger`) vía `replace` local en `go.mod`.
- `config.Config` embebe `config.Base` + `config.Mongo`.
- CRUD `note`: `domain/note` (entidad + puerto `Repository`) → `usecases/note/{create,list,delete}` →
  `repository/note` (adaptador Mongo, BSON ↔ entidad) → `controller/http/note` → `view/*` (templ).
- **HTMX error handling**: `internal/infrastructure/http/httperrors` cablea `htmx.Default` con los
  fragments del proyecto en un `init()` (importado por side-effect en `cmd/api/app.go`).
- **DI con Wire**; `InitializeApp` retorna `(*App, error)` porque la conexión Mongo puede fallar.

## Comandos

```bash
templ generate             # regenera *_templ.go (obligatorio tras tocar .templ)
go generate ./cmd/api      # regenera wire_gen.go
go build ./... && go vet ./... && go test ./...
# runtime (requiere Mongo):
docker run -d --name devmongo -p 27017:27017 mongo:7
ENV=localhost PORT=8080 LOG_LEVEL=debug MONGO_URI=mongodb://localhost:27017 go run ./cmd/api
# abrir http://localhost:8080
```

## Notas

- Los `*_templ.go` son generados — nunca editar a mano; correr `templ generate` tras cambiar `.templ`.
- El nombre de DB es `go-clean-arch-fullstack-sample-<env>_commons` (prefijo + `_commons`).
