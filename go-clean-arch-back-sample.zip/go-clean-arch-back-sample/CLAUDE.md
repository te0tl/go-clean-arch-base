# CLAUDE.md — go-clean-arch-back-sample

@../go-clean-arch-base/CLAUDE.md

Sample **backend-only, stateless** (no persiste nada, como checatufon). Sirve de molde
para servicios que solo exponen una API JSON y delegan en servicios externos.

## Qué demuestra

- Consume **solo el módulo `core`** (sin `mongo`, sin `web`) — vía `replace` local en `go.mod`.
- `config.Config` embebe únicamente `config.Base` (sin fragmentos Mongo/JWT/Email).
- Clean arch: `domain/conversion` (puerto `RatesProvider`) → `usecases/.../convertCurrency` →
  `controller/http/conversion` (JSON) → `router`. El adaptador `service/rates` es estático/offline.
- Errores canónicos + responder JSON `http_errors.Respond`.
- **DI con Wire** (`cmd/api/wire.go` → `wire_gen.go`); `InitializeApp` retorna `*App` (nada puede fallar al arrancar).

## Comandos

```bash
go generate ./cmd/api      # regenera wire_gen.go
go build ./... && go vet ./... && go test ./...
ENV=localhost PORT=8080 LOG_LEVEL=debug go run ./cmd/api
curl "localhost:8080/v1/convert?from=USD&to=MXN&amount=100"
```
