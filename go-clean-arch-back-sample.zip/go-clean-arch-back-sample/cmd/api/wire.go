//go:build wireinject
// +build wireinject

package main

import (
	"go-clean-arch-back-sample/internal/config"
	conversion_controller "go-clean-arch-back-sample/internal/controller/http/conversion"
	"go-clean-arch-back-sample/internal/domain/conversion"
	"go-clean-arch-back-sample/internal/infrastructure/service/rates"
	"go-clean-arch-back-sample/internal/usecases/conversion/convertCurrency"

	"github.com/google/wire"
)

// ServiceSet provides infrastructure adapters (the ports' implementations).
// wire.Bind maps the concrete *rates.Provider to the conversion.RatesProvider
// port the usecase depends on.
var ServiceSet = wire.NewSet(
	rates.NewStaticRatesProvider,
	wire.Bind(new(conversion.RatesProvider), new(*rates.Provider)),
)

// UsecaseSet provides the application usecases.
var UsecaseSet = wire.NewSet(
	convertCurrency.NewConvertCurrencyUsecase,
)

// ControllerSet provides the HTTP controllers.
var ControllerSet = wire.NewSet(
	conversion_controller.NewConversionController,
)

// InitializeApp is the Wire injector. Running `wire` (or `go generate`) reads
// this file — guarded by the wireinject build tag so it's excluded from normal
// builds — and generates wire_gen.go with the concrete construction order.
func InitializeApp(cfg *config.Config) *App {
	wire.Build(
		ServiceSet,
		UsecaseSet,
		ControllerSet,
		newApp,
	)
	return nil
}
