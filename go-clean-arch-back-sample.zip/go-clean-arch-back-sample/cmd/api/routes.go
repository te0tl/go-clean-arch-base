package main

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// RegisterRoutes mounts the HTTP routes. Kept separate from wiring so the route
// table reads top-to-bottom independently of how controllers were built.
func RegisterRoutes(engine *gin.Engine, app *App) {
	engine.GET("/healthz", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok"})
	})

	v1 := engine.Group("/v1")
	{
		v1.GET("/convert", app.ConversionController.Convert)
	}
}
