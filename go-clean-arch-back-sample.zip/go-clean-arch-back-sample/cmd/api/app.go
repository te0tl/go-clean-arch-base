package main

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"

	"go-clean-arch-back-sample/internal/config"
	conversion_controller "go-clean-arch-back-sample/internal/controller/http/conversion"
	"go-clean-arch-back-sample/internal/infrastructure/http/router"

	"github.com/gin-gonic/gin"
)

// App holds the wired application: the HTTP server plus the controllers the
// routes need. Wire assembles it via InitializeApp (see wire.go / wire_gen.go)
// — there is no manual wireDependencies() function.
type App struct {
	Config               *config.Config
	Server               *http.Server
	ConversionController *conversion_controller.ConversionController
}

// newApp is the Wire provider that assembles the App and configures the HTTP
// server. Its parameters are exactly the wired dependencies Wire resolves.
func newApp(cfg *config.Config, conversionController *conversion_controller.ConversionController) *App {
	app := &App{
		Config:               cfg,
		ConversionController: conversionController,
	}

	r := router.SetupRouter(cfg, func(engine *gin.Engine) {
		RegisterRoutes(engine, app)
	})

	app.Server = &http.Server{
		Addr:    fmt.Sprintf(":%d", cfg.Port),
		Handler: r,
	}
	return app
}

func (app *App) StartServer() error {
	slog.Info("Starting HTTP server", "addr", app.Server.Addr)
	go func() {
		if err := app.Server.ListenAndServe(); err != http.ErrServerClosed {
			slog.Error("HTTP server error", "error", err)
		}
	}()
	return nil
}

func (app *App) CloseApp(ctx context.Context) error {
	slog.Info("Shutting down...")
	if err := app.Server.Shutdown(ctx); err != nil {
		return fmt.Errorf("error shutting down server: %w", err)
	}
	slog.Info("Shutdown complete")
	return nil
}
