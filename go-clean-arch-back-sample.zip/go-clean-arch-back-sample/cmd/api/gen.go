package main

// Regenerate wire_gen.go after changing providers or the injector:
//
//	go generate ./cmd/api
//
//go:generate go run github.com/google/wire/cmd/wire gen
