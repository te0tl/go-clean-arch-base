package conversion

import (
	"fmt"

	errors_domain "github.com/te0tl/go-clean-arch-base/core/pkg/domain/errors"
)

// Domain sentinels wrap a canonical category (see core canonical.go) so that
// errors.Is matches BOTH the specific sentinel and its canonical category —
// the HTTP layer maps the canonical category to a status, callers can still
// match the specific sentinel.
var (
	ErrCurrencyRequired    = fmt.Errorf("%w: from and to currencies are required", errors_domain.ErrInvalidInput)
	ErrAmountNotPositive   = fmt.Errorf("%w: amount must be greater than zero", errors_domain.ErrInvalidInput)
	ErrUnsupportedCurrency = fmt.Errorf("%w: unsupported currency", errors_domain.ErrValidation)
)
