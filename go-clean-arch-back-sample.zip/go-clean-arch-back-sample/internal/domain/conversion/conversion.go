package conversion

import "context"

// Conversion is the result of converting an amount between two currencies.
type Conversion struct {
	From   string
	To     string
	Amount float64
	Rate   float64
	Result float64
}

// RatesProvider is the port the usecase depends on to obtain exchange rates.
// Adapters live in internal/infrastructure/service and implement this
// interface (a static table here; an HTTP rates API in a real app). The
// domain declares the port; the outer layers provide it. Dependencies point
// inward.
type RatesProvider interface {
	// GetRate returns how many units of `to` equal one unit of `from`.
	GetRate(ctx context.Context, from, to string) (float64, error)
}
