package router

import (
	"go-clean-arch-back-sample/internal/config"

	"github.com/te0tl/go-clean-arch-base/core/pkg/domain/commons"
	base_logger "github.com/te0tl/go-clean-arch-base/logger"

	"github.com/gin-gonic/gin"
)

// SetupRouter builds the gin engine with the shared logging + panic-recovery
// middleware and defers route registration to the caller (a callback avoids an
// import cycle between this package and cmd/api).
func SetupRouter(cfg *config.Config, registerRoutes func(*gin.Engine)) *gin.Engine {
	if cfg.Env == commons.ENVS.PROD {
		gin.SetMode(gin.ReleaseMode)
	}

	engine := gin.New()
	engine.Use(base_logger.Middleware(base_logger.MiddlewareConfig{
		SkipPaths: map[string]bool{"/healthz": true},
	}))

	registerRoutes(engine)
	return engine
}
