package rates

import (
	"context"
	"strings"

	"go-clean-arch-back-sample/internal/domain/conversion"

	errorsWrapper "github.com/pkg/errors"
)

// Provider is a static, offline RatesProvider adapter. Rates are held against
// USD and cross rates are derived. It lets the sample run with zero external
// dependencies — swap it for an HTTP adapter (same interface) in a real app.
type Provider struct {
	perUSD map[string]float64
}

func NewStaticRatesProvider() *Provider {
	return &Provider{
		perUSD: map[string]float64{
			"USD": 1,
			"MXN": 17.0,
			"EUR": 0.92,
			"GBP": 0.79,
		},
	}
}

func (p *Provider) GetRate(_ context.Context, from, to string) (float64, error) {
	from = strings.ToUpper(strings.TrimSpace(from))
	to = strings.ToUpper(strings.TrimSpace(to))

	fromRate, ok := p.perUSD[from]
	if !ok {
		return 0, errorsWrapper.Wrap(conversion.ErrUnsupportedCurrency, from)
	}
	toRate, ok := p.perUSD[to]
	if !ok {
		return 0, errorsWrapper.Wrap(conversion.ErrUnsupportedCurrency, to)
	}

	return toRate / fromRate, nil
}
