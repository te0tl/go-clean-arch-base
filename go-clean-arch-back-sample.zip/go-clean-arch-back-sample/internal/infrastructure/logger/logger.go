package logger

import (
	"go-clean-arch-back-sample/internal/config"

	"github.com/te0tl/go-clean-arch-base/core/pkg/domain/commons"
	base_logger "github.com/te0tl/go-clean-arch-base/logger"
)

// InitLogger configures the shared structured logger from config. Call once at
// boot before anything logs.
func InitLogger(cfg *config.Config) {
	base_logger.Init(base_logger.InitOpts{
		LogLevel:             base_logger.LOG_LEVEL(cfg.LogLevel),
		IsProd:               cfg.Env == commons.ENVS.PROD,
		IsCloudRun:           cfg.IsRunningInCloudRun(),
		ModuleName:           "go-clean-arch-back-sample",
		GoogleCloudProjectID: cfg.GoogleCloudProjectID,
	})
}
