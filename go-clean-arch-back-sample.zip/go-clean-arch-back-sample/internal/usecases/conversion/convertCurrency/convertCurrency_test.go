package convertCurrency

import (
	"context"
	"errors"
	"testing"

	"go-clean-arch-back-sample/internal/domain/conversion"

	errorsWrapper "github.com/pkg/errors"
	errors_domain "github.com/te0tl/go-clean-arch-base/core/pkg/domain/errors"
	"github.com/te0tl/go-clean-arch-base/core/pkg/testutils"

	"github.com/stretchr/testify/assert"
)

type mockRatesProvider struct {
	rate          float64
	err           error
	getRateCalled bool
}

func (m *mockRatesProvider) GetRate(_ context.Context, _, _ string) (float64, error) {
	m.getRateCalled = true
	return m.rate, m.err
}

// Subtest order mirrors Execute top-to-bottom: input validations first, then
// the dependency error, then the happy path.
func TestConvertCurrencyUsecase_Execute(t *testing.T) {
	t.Run("returns ErrCurrencyRequired when a currency is empty", func(t *testing.T) {
		m := &mockRatesProvider{}
		uc := NewConvertCurrencyUsecase(m)

		_, err := uc.Execute(context.Background(), Input{From: "", To: "MXN", Amount: 10})

		testutils.ErrorAssertions(t, err, conversion.ErrCurrencyRequired, true)
		assert.True(t, errors.Is(err, errors_domain.ErrInvalidInput))
		assert.False(t, m.getRateCalled)
	})

	t.Run("returns ErrAmountNotPositive when amount is not positive", func(t *testing.T) {
		m := &mockRatesProvider{}
		uc := NewConvertCurrencyUsecase(m)

		_, err := uc.Execute(context.Background(), Input{From: "USD", To: "MXN", Amount: 0})

		testutils.ErrorAssertions(t, err, conversion.ErrAmountNotPositive, true)
		assert.False(t, m.getRateCalled)
	})

	t.Run("propagates the rates provider error", func(t *testing.T) {
		provErr := errorsWrapper.Wrap(conversion.ErrUnsupportedCurrency, "XYZ")
		m := &mockRatesProvider{err: provErr}
		uc := NewConvertCurrencyUsecase(m)

		_, err := uc.Execute(context.Background(), Input{From: "USD", To: "XYZ", Amount: 10})

		testutils.ErrorAssertions(t, err, conversion.ErrUnsupportedCurrency, true)
		assert.True(t, m.getRateCalled)
	})

	t.Run("happy path computes the converted amount", func(t *testing.T) {
		m := &mockRatesProvider{rate: 17.0}
		uc := NewConvertCurrencyUsecase(m)

		out, err := uc.Execute(context.Background(), Input{From: "USD", To: "MXN", Amount: 10})

		assert.NoError(t, err)
		assert.Equal(t, 17.0, out.Rate)
		assert.Equal(t, 170.0, out.Result)
		assert.True(t, m.getRateCalled)
	})
}
