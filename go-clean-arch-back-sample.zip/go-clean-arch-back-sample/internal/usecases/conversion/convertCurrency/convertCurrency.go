package convertCurrency

import (
	"context"
	"fmt"

	"go-clean-arch-back-sample/internal/domain/conversion"

	errorsWrapper "github.com/pkg/errors"
)

// Usecase converts a monetary amount between two currencies using a
// RatesProvider port. One usecase = one package = one struct with a
// constructor and Execute (see base CLAUDE.md conventions).
type Usecase struct {
	rates conversion.RatesProvider
}

func NewConvertCurrencyUsecase(rates conversion.RatesProvider) *Usecase {
	return &Usecase{rates: rates}
}

type Input struct {
	From   string
	To     string
	Amount float64
}

func (u *Usecase) Execute(ctx context.Context, in Input) (*conversion.Conversion, error) {
	if in.From == "" || in.To == "" {
		return nil, errorsWrapper.Wrap(conversion.ErrCurrencyRequired, "validating input")
	}
	if in.Amount <= 0 {
		return nil, errorsWrapper.Wrap(conversion.ErrAmountNotPositive, "validating input")
	}

	rate, err := u.rates.GetRate(ctx, in.From, in.To)
	if err != nil {
		return nil, fmt.Errorf("getting rate %s->%s: %w", in.From, in.To, err)
	}

	return &conversion.Conversion{
		From:   in.From,
		To:     in.To,
		Amount: in.Amount,
		Rate:   rate,
		Result: in.Amount * rate,
	}, nil
}
