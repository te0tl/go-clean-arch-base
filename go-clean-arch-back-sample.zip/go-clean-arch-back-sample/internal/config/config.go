package config

import (
	base_config "github.com/te0tl/go-clean-arch-base/core/pkg/config"
)

// Config is the application configuration. This backend-only sample is
// stateless, so it embeds ONLY config.Base — no Mongo, JWT, Email or Frontend
// fragments. A service that persists would add `base_config.Mongo`, one that
// issues tokens would add `base_config.JWT`, and so on.
type Config struct {
	base_config.Base
}

func Load() *Config {
	cfg := &Config{}
	base_config.LoadEnv(cfg)
	cfg.Validate()
	return cfg
}
