package conversion_controller

// convertRequest binds the query string for GET /v1/convert. The `form` tag is
// the query param name; `binding` drives validation (translated to per-field
// JSON errors by http_errors.Respond).
type convertRequest struct {
	From   string  `form:"from" binding:"required"`
	To     string  `form:"to" binding:"required"`
	Amount float64 `form:"amount" binding:"required,gt=0"`
}
