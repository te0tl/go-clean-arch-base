package conversion_controller

import (
	"net/http"

	"go-clean-arch-back-sample/internal/usecases/conversion/convertCurrency"

	http_errors "github.com/te0tl/go-clean-arch-base/core/pkg/infrastructure/http/errors"

	"github.com/gin-gonic/gin"
)

type ConversionController struct {
	convertUC *convertCurrency.Usecase
}

func NewConversionController(convertUC *convertCurrency.Usecase) *ConversionController {
	return &ConversionController{convertUC: convertUC}
}

type convertResponse struct {
	From   string  `json:"from"`
	To     string  `json:"to"`
	Amount float64 `json:"amount"`
	Rate   float64 `json:"rate"`
	Result float64 `json:"result"`
}

// Convert handles GET /v1/convert?from=USD&to=MXN&amount=100.
func (ctrl *ConversionController) Convert(c *gin.Context) {
	var req convertRequest
	if err := c.ShouldBindQuery(&req); err != nil {
		http_errors.Respond(c, err)
		return
	}

	out, err := ctrl.convertUC.Execute(c.Request.Context(), convertCurrency.Input{
		From:   req.From,
		To:     req.To,
		Amount: req.Amount,
	})
	if err != nil {
		http_errors.Respond(c, err)
		return
	}

	c.JSON(http.StatusOK, convertResponse{
		From:   out.From,
		To:     out.To,
		Amount: out.Amount,
		Rate:   out.Rate,
		Result: out.Result,
	})
}
