//go:build tools
// +build tools

// Package tools pins build-time tool dependencies (the Wire code generator) so
// `go generate` resolves them from go.mod. It is never compiled into the app.
package tools

import _ "github.com/google/wire/cmd/wire"
